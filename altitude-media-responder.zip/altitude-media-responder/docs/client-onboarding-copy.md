# Client onboarding copy

## Welcome screen headline
Connect your accounts and let Altitude Media Responder start handling comments and reviews for you.

## Facebook help text
Click **Connect Facebook** and sign into the Facebook account that manages your business Page. Choose your Page, approve access, and come right back.

## Google help text
Click **Connect Google Business Profile** and sign into the Google account that manages your Business Profile. Approve access and return to the dashboard.

## Approval mode explainer
- **Auto Reply**: simple low-risk items are answered immediately.
- **Approval Required**: the system drafts replies and waits for you.
- **Suggestion Only**: nothing gets posted automatically.
