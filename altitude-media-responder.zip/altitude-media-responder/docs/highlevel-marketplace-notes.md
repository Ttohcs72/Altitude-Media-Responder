# HighLevel marketplace notes for Altitude Media Responder

## Start as a Private app
That is the right move for your free founders rollout.

- Distribution: Private
- Install target: Sub-account
- OAuth type: Authorization Code
- Redirect URI: `https://YOUR_DOMAIN/api/auth/highlevel/callback`
- Suggested scopes:
  - `contacts.readonly`
  - `contacts.write`
  - `conversations.readonly`
  - `conversations.write`
  - `locations.readonly`
  - `users.readonly`

## Later switch to Public
When you are ready for Marketplace:

- add branding assets
- add support email
- add privacy policy and terms
- add install/onboarding copy
- test installer flow in a sandbox agency and a sandbox location

## Recommended iframe page
Use `/dashboard` as the embedded app UI.
