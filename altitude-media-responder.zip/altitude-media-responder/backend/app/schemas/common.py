from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict


class ClientCreate(BaseModel):
    company_name: str
    ghl_location_id: Optional[str] = None
    contact_email: Optional[str] = None
    brand_voice: str = 'Friendly, helpful, professional, concise'
    business_description: Optional[str] = None
    lead_link: Optional[str] = None


class ClientRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    company_name: str
    ghl_location_id: Optional[str]
    contact_email: Optional[str]
    auto_reply_mode: str
    brand_voice: str
    business_description: Optional[str]
    lead_link: Optional[str]
    created_at: datetime


class InteractionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    platform: str
    interaction_type: str
    author_name: Optional[str]
    rating: Optional[int]
    text: str
    sentiment: Optional[str]
    intent: Optional[str]
    risk_level: Optional[str]
    ai_reply: Optional[str]
    final_reply: Optional[str]
    status: str
    created_at: datetime


class SuggestionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    topic: str
    hook: str
    caption: str
    cta: str
    platform: str
    source_summary: Optional[str]
    created_at: datetime
