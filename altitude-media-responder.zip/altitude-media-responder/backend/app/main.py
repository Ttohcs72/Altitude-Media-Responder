from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.api.routes import router as api_router
from app.db.session import Base, engine
from app.models import *  # noqa: F401,F403

Base.metadata.create_all(bind=engine)

app = FastAPI(title='Altitude Media Responder')
app.include_router(api_router, prefix='/api')
app.mount('/static', StaticFiles(directory='app/static'), name='static')
templates = Jinja2Templates(directory='app/templates')


@app.get('/')
def root():
    return FileResponse('app/templates/index.html')


@app.get('/dashboard')
def dashboard():
    return FileResponse('app/templates/dashboard.html')
