from __future__ import annotations

from datetime import datetime
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base


class Client(Base):
    __tablename__ = 'clients'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    ghl_location_id: Mapped[str | None] = mapped_column(String(100), unique=True, index=True)
    company_name: Mapped[str] = mapped_column(String(255))
    timezone: Mapped[str] = mapped_column(String(100), default='America/Denver')
    contact_email: Mapped[str | None] = mapped_column(String(255))
    brand_voice: Mapped[str] = mapped_column(Text, default='Friendly, helpful, professional, concise')
    business_description: Mapped[str | None] = mapped_column(Text)
    auto_reply_mode: Mapped[str] = mapped_column(String(20), default='approval')
    lead_link: Mapped[str | None] = mapped_column(String(500))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    settings_json: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    integrations: Mapped[list[IntegrationToken]] = relationship(back_populates='client', cascade='all, delete-orphan')
    posts: Mapped[list[Post]] = relationship(back_populates='client', cascade='all, delete-orphan')
    interactions: Mapped[list[Interaction]] = relationship(back_populates='client', cascade='all, delete-orphan')
    suggestions: Mapped[list[ContentSuggestion]] = relationship(back_populates='client', cascade='all, delete-orphan')


class IntegrationToken(Base):
    __tablename__ = 'integration_tokens'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey('clients.id', ondelete='CASCADE'))
    provider: Mapped[str] = mapped_column(String(50), index=True)
    access_token: Mapped[str] = mapped_column(Text)
    refresh_token: Mapped[str | None] = mapped_column(Text)
    external_account_id: Mapped[str | None] = mapped_column(String(255))
    external_account_name: Mapped[str | None] = mapped_column(String(255))
    scopes: Mapped[str | None] = mapped_column(Text)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime)
    metadata_json: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    client: Mapped[Client] = relationship(back_populates='integrations')


class Post(Base):
    __tablename__ = 'posts'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey('clients.id', ondelete='CASCADE'), index=True)
    platform: Mapped[str] = mapped_column(String(30), index=True)
    external_post_id: Mapped[str] = mapped_column(String(255), index=True)
    message: Mapped[str | None] = mapped_column(Text)
    media_type: Mapped[str | None] = mapped_column(String(50))
    posted_at: Mapped[datetime | None] = mapped_column(DateTime)
    metrics_json: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    client: Mapped[Client] = relationship(back_populates='posts')


class Interaction(Base):
    __tablename__ = 'interactions'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey('clients.id', ondelete='CASCADE'), index=True)
    platform: Mapped[str] = mapped_column(String(30), index=True)
    interaction_type: Mapped[str] = mapped_column(String(30), index=True)  # comment, review
    external_id: Mapped[str] = mapped_column(String(255), index=True)
    parent_external_id: Mapped[str | None] = mapped_column(String(255))
    author_name: Mapped[str | None] = mapped_column(String(255))
    author_id: Mapped[str | None] = mapped_column(String(255))
    rating: Mapped[int | None] = mapped_column(Integer)
    text: Mapped[str] = mapped_column(Text)
    sentiment: Mapped[str | None] = mapped_column(String(50))
    intent: Mapped[str | None] = mapped_column(String(50))
    risk_level: Mapped[str | None] = mapped_column(String(20))
    ai_reply: Mapped[str | None] = mapped_column(Text)
    final_reply: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default='pending')
    meta_json: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    replied_at: Mapped[datetime | None] = mapped_column(DateTime)

    client: Mapped[Client] = relationship(back_populates='interactions')


class ContentSuggestion(Base):
    __tablename__ = 'content_suggestions'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey('clients.id', ondelete='CASCADE'), index=True)
    topic: Mapped[str] = mapped_column(String(255))
    hook: Mapped[str] = mapped_column(Text)
    caption: Mapped[str] = mapped_column(Text)
    cta: Mapped[str] = mapped_column(Text)
    platform: Mapped[str] = mapped_column(String(50), default='facebook')
    source_summary: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    client: Mapped[Client] = relationship(back_populates='suggestions')
