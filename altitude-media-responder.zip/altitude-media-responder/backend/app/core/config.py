from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    app_name: str = 'Altitude Media Responder'
    app_env: str = 'development'
    app_secret: str = 'change-me'
    base_url: str = 'http://localhost:8000'
    frontend_base_url: str = 'http://localhost:8000'

    database_url: str = 'postgresql+psycopg://amr:amr@db:5432/amr'
    redis_url: str = 'redis://redis:6379/0'

    openai_api_key: str = ''
    openai_model: str = 'gpt-4.1-mini'

    ghl_client_id: str = ''
    ghl_client_secret: str = ''
    ghl_redirect_uri: str = 'http://localhost:8000/api/auth/highlevel/callback'
    ghl_scopes: str = 'contacts.write contacts.readonly conversations.readonly conversations.write locations.readonly users.readonly'

    facebook_app_id: str = ''
    facebook_app_secret: str = ''
    facebook_redirect_uri: str = 'http://localhost:8000/api/auth/facebook/callback'
    facebook_verify_token: str = 'replace-me'
    facebook_graph_version: str = 'v23.0'

    google_client_id: str = ''
    google_client_secret: str = ''
    google_redirect_uri: str = 'http://localhost:8000/api/auth/google/callback'

    default_auto_reply_mode: str = 'approval'


settings = Settings()
