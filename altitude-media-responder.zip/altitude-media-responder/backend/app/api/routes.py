from __future__ import annotations

from datetime import datetime, timedelta
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.core.config import settings
from app.models import Client, ContentSuggestion, IntegrationToken, Interaction
from app.schemas.common import ClientCreate, ClientRead, InteractionRead, SuggestionRead
from app.services.ai import ai_service
from app.services.facebook import facebook_service
from app.services.google_business import google_business_service
from app.services.highlevel import highlevel_service
from app.services.oauth_state import dumps as dump_state, loads as load_state
from app.services.security import decrypt_value, encrypt_value

router = APIRouter()


@router.get('/health')
def health():
    return {'ok': True, 'app': settings.app_name}


@router.post('/clients', response_model=ClientRead)
def create_client(payload: ClientCreate, db: Session = Depends(get_db)):
    client = Client(**payload.model_dump())
    db.add(client)
    db.commit()
    db.refresh(client)
    return client


@router.get('/clients', response_model=list[ClientRead])
def list_clients(db: Session = Depends(get_db)):
    return db.execute(select(Client).order_by(Client.company_name)).scalars().all()


@router.get('/clients/{client_id}/interactions', response_model=list[InteractionRead])
def list_interactions(client_id: int, db: Session = Depends(get_db)):
    return db.execute(select(Interaction).where(Interaction.client_id == client_id).order_by(Interaction.created_at.desc()).limit(100)).scalars().all()


@router.get('/clients/{client_id}/suggestions', response_model=list[SuggestionRead])
def list_suggestions(client_id: int, db: Session = Depends(get_db)):
    return db.execute(select(ContentSuggestion).where(ContentSuggestion.client_id == client_id).order_by(ContentSuggestion.created_at.desc()).limit(50)).scalars().all()


@router.post('/clients/{client_id}/suggestions/generate', response_model=list[SuggestionRead])
def generate_suggestions(client_id: int, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(404, 'Client not found')
    recent = db.execute(select(Interaction).where(Interaction.client_id == client_id).order_by(Interaction.created_at.desc()).limit(10)).scalars().all()
    examples = [x.text for x in recent]
    suggestions = ai_service.generate_suggestions(client.company_name, client.brand_voice, examples)
    records = []
    for item in suggestions:
        row = ContentSuggestion(client_id=client_id, **item)
        db.add(row)
        records.append(row)
    db.commit()
    for row in records:
        db.refresh(row)
    return records


@router.get('/auth/facebook/start/{client_id}')
def facebook_start(client_id: int):
    state = dump_state({'client_id': client_id})
    params = {
        'client_id': settings.facebook_app_id,
        'redirect_uri': settings.facebook_redirect_uri,
        'state': state,
        'scope': 'pages_manage_engagement,pages_read_engagement,pages_show_list',
        'response_type': 'code',
    }
    return RedirectResponse(f'https://www.facebook.com/{settings.facebook_graph_version}/dialog/oauth?{urlencode(params)}')


@router.get('/auth/facebook/callback')
async def facebook_callback(code: str, state: str, db: Session = Depends(get_db)):
    payload = load_state(state)
    client_id = payload['client_id']
    token = await facebook_service.exchange_code_for_token(code)
    user_access_token = token['access_token']
    pages = await facebook_service.get_pages(user_access_token)
    first_page = (pages.get('data') or [None])[0]
    if not first_page:
        raise HTTPException(400, 'No Facebook pages found for this user.')
    record = IntegrationToken(
        client_id=client_id,
        provider='facebook',
        access_token=encrypt_value(first_page['access_token']),
        external_account_id=first_page.get('id'),
        external_account_name=first_page.get('name'),
        metadata_json=pages,
    )
    db.add(record)
    db.commit()
    return RedirectResponse(f'{settings.frontend_base_url}/dashboard?connected=facebook')


@router.get('/auth/google/start/{client_id}')
def google_start(client_id: int):
    state = dump_state({'client_id': client_id})
    params = {
        'client_id': settings.google_client_id,
        'redirect_uri': settings.google_redirect_uri,
        'response_type': 'code',
        'access_type': 'offline',
        'prompt': 'consent',
        'scope': 'https://www.googleapis.com/auth/business.manage',
        'state': state,
    }
    return RedirectResponse(f'https://accounts.google.com/o/oauth2/v2/auth?{urlencode(params)}')


@router.get('/auth/google/callback')
async def google_callback(code: str, state: str, db: Session = Depends(get_db)):
    payload = load_state(state)
    client_id = payload['client_id']
    token = await google_business_service.exchange_code_for_token(code)
    accounts = await google_business_service.list_accounts(token['access_token'])
    first_account = (accounts.get('accounts') or [None])[0]
    if not first_account:
        raise HTTPException(400, 'No Google Business Profile account found.')
    record = IntegrationToken(
        client_id=client_id,
        provider='google_business',
        access_token=encrypt_value(token['access_token']),
        refresh_token=encrypt_value(token.get('refresh_token', '')) if token.get('refresh_token') else None,
        external_account_id=first_account.get('name', '').split('/')[-1],
        external_account_name=first_account.get('accountName'),
        scopes=token.get('scope'),
        expires_at=datetime.utcnow() + timedelta(seconds=int(token.get('expires_in', 3600))),
        metadata_json=accounts,
    )
    db.add(record)
    db.commit()
    return RedirectResponse(f'{settings.frontend_base_url}/dashboard?connected=google')


@router.get('/auth/highlevel/start')
def highlevel_start():
    params = {
        'response_type': 'code',
        'redirect_uri': settings.ghl_redirect_uri,
        'client_id': settings.ghl_client_id,
        'scope': settings.ghl_scopes,
    }
    return RedirectResponse(f'{highlevel_service.auth_url}?{urlencode(params)}')


@router.get('/auth/highlevel/callback')
async def highlevel_callback(code: str):
    token = await highlevel_service.exchange_code_for_token(code)
    return JSONResponse({'connected': True, 'token_response': token})


@router.get('/webhooks/facebook')
def facebook_verify(request: Request):
    mode = request.query_params.get('hub.mode')
    token = request.query_params.get('hub.verify_token')
    challenge = request.query_params.get('hub.challenge')
    if mode == 'subscribe' and token == settings.facebook_verify_token:
        return HTMLResponse(content=challenge or '')
    raise HTTPException(403, 'Verification failed')


@router.post('/webhooks/facebook')
async def facebook_webhook(payload: dict, db: Session = Depends(get_db)):
    changes = payload.get('entry', [])
    created = []
    for entry in changes:
        for change in entry.get('changes', []):
            value = change.get('value', {})
            comment_text = value.get('message')
            comment_id = value.get('comment_id') or value.get('id')
            page_id = value.get('post_id', '').split('_')[0] if value.get('post_id') else None
            if not comment_text or not comment_id:
                continue
            integ = db.execute(select(IntegrationToken).where(IntegrationToken.provider == 'facebook', IntegrationToken.external_account_id == page_id)).scalar_one_or_none()
            if not integ:
                continue
            client = db.get(Client, integ.client_id)
            analysis = ai_service.analyze_interaction(client.company_name, client.brand_voice, comment_text)
            interaction = Interaction(
                client_id=client.id,
                platform='facebook',
                interaction_type='comment',
                external_id=comment_id,
                parent_external_id=value.get('post_id'),
                author_name=value.get('from', {}).get('name'),
                author_id=value.get('from', {}).get('id'),
                text=comment_text,
                sentiment=analysis.get('sentiment'),
                intent=analysis.get('intent'),
                risk_level=analysis.get('risk_level'),
                ai_reply=analysis.get('reply'),
                status='approved' if client.auto_reply_mode == 'auto' and analysis.get('risk_level') == 'low' else 'pending',
                meta_json=value,
            )
            db.add(interaction)
            created.append(interaction)
            if interaction.status == 'approved':
                await facebook_service.reply_to_comment(comment_id, interaction.ai_reply or '', decrypt_value(integ.access_token))
                interaction.final_reply = interaction.ai_reply
                interaction.status = 'sent'
                interaction.replied_at = datetime.utcnow()
    db.commit()
    return {'received': True, 'created': len(created)}


@router.post('/actions/interactions/{interaction_id}/approve')
async def approve_interaction(interaction_id: int, db: Session = Depends(get_db)):
    interaction = db.get(Interaction, interaction_id)
    if not interaction:
        raise HTTPException(404, 'Interaction not found')
    integ = db.execute(select(IntegrationToken).where(IntegrationToken.client_id == interaction.client_id, IntegrationToken.provider == interaction.platform if interaction.platform != 'google' else 'google_business')).scalar_one_or_none()
    if interaction.platform == 'facebook':
        await facebook_service.reply_to_comment(interaction.external_id, interaction.ai_reply or '', decrypt_value(integ.access_token))
    interaction.final_reply = interaction.ai_reply
    interaction.status = 'sent'
    interaction.replied_at = datetime.utcnow()
    db.commit()
    db.refresh(interaction)
    return interaction
