from __future__ import annotations

import httpx
from app.core.config import settings


class HighLevelService:
    auth_url = 'https://services.leadconnectorhq.com/oauth/authorize'
    token_url = 'https://services.leadconnectorhq.com/oauth/token'
    api_base = 'https://services.leadconnectorhq.com'

    async def exchange_code_for_token(self, code: str) -> dict:
        data = {
            'client_id': settings.ghl_client_id,
            'client_secret': settings.ghl_client_secret,
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': settings.ghl_redirect_uri,
            'user_type': 'Location',
        }
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(self.token_url, json=data)
            r.raise_for_status()
            return r.json()

    async def create_contact(self, access_token: str, location_id: str, name: str | None, email: str | None, phone: str | None, tags: list[str]) -> dict:
        payload = {
            'locationId': location_id,
            'firstName': name or 'Social',
            'email': email,
            'phone': phone,
            'tags': tags,
        }
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                f'{self.api_base}/contacts/',
                headers={'Authorization': f'Bearer {access_token}', 'Version': '2021-07-28'},
                json=payload,
            )
            r.raise_for_status()
            return r.json()


highlevel_service = HighLevelService()
