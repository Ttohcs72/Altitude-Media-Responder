from __future__ import annotations

import httpx
from app.core.config import settings


class FacebookService:
    base = f'https://graph.facebook.com/{settings.facebook_graph_version}'

    async def exchange_code_for_token(self, code: str) -> dict:
        params = {
            'client_id': settings.facebook_app_id,
            'redirect_uri': settings.facebook_redirect_uri,
            'client_secret': settings.facebook_app_secret,
            'code': code,
        }
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(f'{self.base}/oauth/access_token', params=params)
            r.raise_for_status()
            return r.json()

    async def get_pages(self, access_token: str) -> dict:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(f'{self.base}/me/accounts', params={'access_token': access_token})
            r.raise_for_status()
            return r.json()

    async def reply_to_comment(self, comment_id: str, message: str, page_access_token: str) -> dict:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(f'{self.base}/{comment_id}/comments', data={'message': message, 'access_token': page_access_token})
            r.raise_for_status()
            return r.json()


facebook_service = FacebookService()
