from itsdangerous import URLSafeSerializer
from app.core.config import settings

serializer = URLSafeSerializer(settings.app_secret, salt='oauth-state')


def dumps(payload: dict) -> str:
    return serializer.dumps(payload)


def loads(token: str) -> dict:
    return serializer.loads(token)
