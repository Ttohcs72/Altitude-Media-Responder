from cryptography.fernet import Fernet
from base64 import urlsafe_b64encode
from hashlib import sha256

from app.core.config import settings


def _build_key() -> bytes:
    return urlsafe_b64encode(sha256(settings.app_secret.encode()).digest())


def encrypt_value(value: str) -> str:
    return Fernet(_build_key()).encrypt(value.encode()).decode()


def decrypt_value(value: str) -> str:
    return Fernet(_build_key()).decrypt(value.encode()).decode()
