from __future__ import annotations

import httpx
from app.core.config import settings


class GoogleBusinessService:
    token_url = 'https://oauth2.googleapis.com/token'
    api_base = 'https://mybusiness.googleapis.com/v4'

    async def exchange_code_for_token(self, code: str) -> dict:
        data = {
            'code': code,
            'client_id': settings.google_client_id,
            'client_secret': settings.google_client_secret,
            'redirect_uri': settings.google_redirect_uri,
            'grant_type': 'authorization_code',
        }
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(self.token_url, data=data)
            r.raise_for_status()
            return r.json()

    async def refresh_token(self, refresh_token: str) -> dict:
        data = {
            'client_id': settings.google_client_id,
            'client_secret': settings.google_client_secret,
            'refresh_token': refresh_token,
            'grant_type': 'refresh_token',
        }
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(self.token_url, data=data)
            r.raise_for_status()
            return r.json()

    async def list_accounts(self, access_token: str) -> dict:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(f'{self.api_base}/accounts', headers={'Authorization': f'Bearer {access_token}'})
            r.raise_for_status()
            return r.json()

    async def list_reviews(self, account_id: str, location_id: str, access_token: str) -> dict:
        url = f'{self.api_base}/accounts/{account_id}/locations/{location_id}/reviews'
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(url, headers={'Authorization': f'Bearer {access_token}'})
            r.raise_for_status()
            return r.json()

    async def reply_to_review(self, account_id: str, location_id: str, review_id: str, comment: str, access_token: str) -> dict:
        url = f'{self.api_base}/accounts/{account_id}/locations/{location_id}/reviews/{review_id}/reply'
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.put(url, headers={'Authorization': f'Bearer {access_token}'}, json={'comment': comment})
            r.raise_for_status()
            return r.json()


google_business_service = GoogleBusinessService()
