from __future__ import annotations

import json
from typing import Iterable
from openai import OpenAI

from app.core.config import settings


class AIService:
    def __init__(self) -> None:
        self.client = OpenAI(api_key=settings.openai_api_key) if settings.openai_api_key else None

    def analyze_interaction(self, business_name: str, brand_voice: str, text: str) -> dict:
        if not self.client:
            lowered = text.lower()
            intent = 'lead' if any(k in lowered for k in ['price', 'quote', 'cost', 'estimate', 'book', 'available']) else 'general'
            risk = 'high' if any(k in lowered for k in ['lawyer', 'refund', 'angry', 'scam', 'terrible']) else 'low'
            sentiment = 'negative' if any(k in lowered for k in ['bad', 'terrible', 'slow']) else 'positive'
            reply = f"Thanks for reaching out to {business_name}! We appreciate your message and will follow up shortly."
            return {'sentiment': sentiment, 'intent': intent, 'risk_level': risk, 'reply': reply}

        prompt = f'''You are the social engagement assistant for {business_name}.\nBrand voice: {brand_voice}.\nAnalyze the interaction and return strict JSON with keys sentiment, intent, risk_level, reply.\nText: {text}'''
        result = self.client.responses.create(model=settings.openai_model, input=prompt)
        content = result.output_text.strip()
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return {'sentiment': 'neutral', 'intent': 'general', 'risk_level': 'medium', 'reply': content[:1000]}

    def generate_suggestions(self, business_name: str, brand_voice: str, examples: Iterable[str]) -> list[dict]:
        examples_blob = '\n'.join(f'- {x}' for x in examples)
        if not self.client:
            return [
                {
                    'topic': 'Customer question spotlight',
                    'hook': f'What do customers ask {business_name} the most?',
                    'caption': 'Here is a quick answer to one of the biggest questions we hear every week.',
                    'cta': 'Send us a message for a personalized quote.',
                    'platform': 'facebook',
                    'source_summary': 'Generated from recent engagement patterns.',
                }
            ]
        prompt = f'''You create local-business Facebook posts.\nBusiness: {business_name}\nVoice: {brand_voice}\nRecent winning insights:\n{examples_blob}\nReturn JSON array with 5 items. Each item must have topic, hook, caption, cta, platform, source_summary.'''
        result = self.client.responses.create(model=settings.openai_model, input=prompt)
        try:
            return json.loads(result.output_text)
        except json.JSONDecodeError:
            return []


ai_service = AIService()
