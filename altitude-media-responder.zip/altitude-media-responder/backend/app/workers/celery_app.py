from celery import Celery
from app.core.config import settings

celery = Celery('amr', broker=settings.redis_url, backend=settings.redis_url)
celery.conf.beat_schedule = {
    'poll-google-reviews-every-5-min': {
        'task': 'app.workers.tasks.poll_google_reviews',
        'schedule': 300.0,
    },
    'generate-weekly-suggestions-daily': {
        'task': 'app.workers.tasks.refresh_content_suggestions',
        'schedule': 86400.0,
    },
}
