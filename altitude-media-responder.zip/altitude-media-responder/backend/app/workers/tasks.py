from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
from sqlalchemy import select

from app.db.session import SessionLocal
from app.models import Client, ContentSuggestion, IntegrationToken, Interaction
from app.services.ai import ai_service
from app.services.google_business import google_business_service
from app.services.security import decrypt_value, encrypt_value
from app.workers.celery_app import celery


@celery.task(name='app.workers.tasks.poll_google_reviews')
def poll_google_reviews() -> dict:
    return asyncio.run(_poll_google_reviews())


async def _poll_google_reviews() -> dict:
    db = SessionLocal()
    created = 0
    try:
        rows = db.execute(select(IntegrationToken).where(IntegrationToken.provider == 'google_business')).scalars().all()
        for integ in rows:
            access_token = decrypt_value(integ.access_token)
            if integ.expires_at and integ.expires_at <= datetime.utcnow() + timedelta(minutes=5) and integ.refresh_token:
                refreshed = await google_business_service.refresh_token(decrypt_value(integ.refresh_token))
                access_token = refreshed['access_token']
                integ.access_token = encrypt_value(access_token)
                integ.expires_at = datetime.utcnow() + timedelta(seconds=int(refreshed.get('expires_in', 3600)))
                db.commit()

            account_id = integ.external_account_id
            location_id = (integ.metadata_json or {}).get('default_location_id')
            if not account_id or not location_id:
                continue
            client = db.get(Client, integ.client_id)
            payload = await google_business_service.list_reviews(account_id, location_id, access_token)
            for review in payload.get('reviews', []):
                ext_id = review['reviewId']
                exists = db.execute(select(Interaction).where(Interaction.external_id == ext_id, Interaction.platform == 'google')).scalar_one_or_none()
                if exists:
                    continue
                text = review.get('comment') or f"{review.get('starRating', 'STAR_RATING_UNSPECIFIED')} review"
                analysis = ai_service.analyze_interaction(client.company_name, client.brand_voice, text)
                interaction = Interaction(
                    client_id=client.id,
                    platform='google',
                    interaction_type='review',
                    external_id=ext_id,
                    author_name=(review.get('reviewer') or {}).get('displayName'),
                    rating=_star_value(review.get('starRating')),
                    text=text,
                    sentiment=analysis.get('sentiment'),
                    intent='review',
                    risk_level=analysis.get('risk_level'),
                    ai_reply=analysis.get('reply'),
                    status='approved' if client.auto_reply_mode == 'auto' and analysis.get('risk_level') == 'low' else 'pending',
                    meta_json=review,
                )
                db.add(interaction)
                created += 1
                if interaction.status == 'approved':
                    await google_business_service.reply_to_review(account_id, location_id, ext_id, interaction.ai_reply or '', access_token)
                    interaction.final_reply = interaction.ai_reply
                    interaction.status = 'sent'
                    interaction.replied_at = datetime.utcnow()
            db.commit()
    finally:
        db.close()
    return {'created': created}


@celery.task(name='app.workers.tasks.refresh_content_suggestions')
def refresh_content_suggestions() -> dict:
    db = SessionLocal()
    count = 0
    try:
        clients = db.execute(select(Client).where(Client.is_active == True)).scalars().all()  # noqa: E712
        for client in clients:
            recent = db.execute(select(Interaction).where(Interaction.client_id == client.id).order_by(Interaction.created_at.desc()).limit(10)).scalars().all()
            examples = [r.text for r in recent]
            suggestions = ai_service.generate_suggestions(client.company_name, client.brand_voice, examples)
            for item in suggestions[:5]:
                db.add(ContentSuggestion(client_id=client.id, **item))
                count += 1
        db.commit()
    finally:
        db.close()
    return {'suggestions_created': count}


def _star_value(value: str | None) -> int | None:
    mapping = {
        'ONE': 1,
        'TWO': 2,
        'THREE': 3,
        'FOUR': 4,
        'FIVE': 5,
        'ONE_STAR': 1,
        'TWO_STAR': 2,
        'THREE_STAR': 3,
        'FOUR_STAR': 4,
        'FIVE_STAR': 5,
    }
    return mapping.get((value or '').replace('STAR_RATING_', ''))
