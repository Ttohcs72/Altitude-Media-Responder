# Altitude Media Responder

Altitude Media Responder is a HighLevel-friendly AI engagement service for local businesses. It focuses on the two channels that matter most for local operators:

- **Facebook Page comments**
- **Google Business Profile reviews**

It monitors incoming activity, drafts or sends replies, flags risky items for approval, stores analytics, and generates new post ideas from what is already getting traction.

## What is included

- FastAPI backend
- PostgreSQL data model
- Redis + Celery worker and scheduler
- Facebook comment webhook endpoint
- Google Business review polling worker
- OpenAI-powered reply and content suggestion service
- Starter dashboard pages that can be embedded in a HighLevel custom app iframe
- HighLevel OAuth starter wiring
- Docker deployment
- Non-technical client onboarding flow using **Connect Facebook** and **Connect Google Business** buttons instead of manual API-key hunting

## Product positioning

### Free founders rollout
Use it first as a **private HighLevel app** for your current clients. Once stable, convert it to a **public marketplace app**.

## Architecture

```text
Facebook Webhooks  --->  FastAPI API  ---> PostgreSQL
Google Review Poll --->  Celery Worker ---> PostgreSQL
                                 |-----> OpenAI
                                 |-----> HighLevel CRM
Dashboard / HighLevel iframe ---> FastAPI templates
```

## Core workflows

### 1. Facebook comment monitoring
1. Client clicks **Connect Facebook**.
2. Facebook OAuth returns a user token.
3. The app fetches pages the user manages and stores the selected Page token.
4. Facebook sends comment events to `/api/webhooks/facebook`.
5. The AI service classifies the comment and drafts a reply.
6. If the client is in auto mode and the risk is low, the reply is posted automatically.
7. If risk is medium/high, it lands in the approval queue.

### 2. Google review monitoring
1. Client clicks **Connect Google Business**.
2. Google OAuth returns an access token + refresh token.
3. The app stores the Business Profile account token.
4. A Celery job polls Google Business Profile reviews every 5 minutes.
5. New reviews are analyzed and drafted.
6. Low-risk reviews can be auto-replied.
7. Others wait for approval.

### 3. Content refinement
A scheduled task reads recent interactions, then writes fresh content suggestions into `content_suggestions`.

## Important reality checks

- This repo is built as a **working starter/MVP**, not a fully finished enterprise product.
- Facebook setup still requires your own Meta app and webhook subscription.
- Google Business Profile setup still requires your own Google Cloud OAuth credentials and API enablement.
- HighLevel setup still requires your own Marketplace/private app credentials.
- Google review polling is implemented; Google Q&A is **not included in this version**.

## Quick start

```bash
cp .env.example .env
# fill in your real credentials
./scripts/start_local.sh
```

Open:
- API: `http://localhost:8000`
- Flower: `http://localhost:5555`

## Create your first client

Example request:

```bash
curl -X POST http://localhost:8000/api/clients \
  -H 'Content-Type: application/json' \
  -d '{
    "company_name":"TLCscapes",
    "contact_email":"owner@example.com",
    "brand_voice":"Friendly, professional, concise, local",
    "business_description":"Landscape design and outdoor living company",
    "lead_link":"https://your-booking-link.example.com"
  }'
```

Then open these links, replacing `1` with the client ID:

- `http://localhost:8000/api/auth/facebook/start/1`
- `http://localhost:8000/api/auth/google/start/1`

## Client onboarding for non-technical business owners

This part matters. Do **not** ask them to search for API keys.

### Facebook onboarding script
Send them a page with a button labeled:

**Connect Facebook**

When they click it:
1. They log into Facebook.
2. They choose the business Page they manage.
3. They approve access.
4. They are returned to your dashboard.

### Google onboarding script
Send them a page with a button labeled:

**Connect Google Business Profile**

When they click it:
1. They log into the Google account that owns the Business Profile.
2. They approve access.
3. They are returned to your dashboard.

## Exact setup you need before clients can connect

### A. Meta / Facebook
1. Create a Meta app in the Meta developer console.
2. Add Facebook Login.
3. Add the Pages permissions used by this app.
4. Set the OAuth redirect URI to:
   - `https://YOUR_DOMAIN/api/auth/facebook/callback`
5. Set the webhook callback to:
   - `https://YOUR_DOMAIN/api/webhooks/facebook`
6. Set the verify token to match `FACEBOOK_VERIFY_TOKEN`.

### B. Google Business Profile
1. In Google Cloud Console, create a project.
2. Enable Business Profile APIs.
3. Configure OAuth consent.
4. Create OAuth 2.0 Web credentials.
5. Add redirect URI:
   - `https://YOUR_DOMAIN/api/auth/google/callback`

### C. HighLevel
1. Create a developer account in the HighLevel Marketplace.
2. Create the app as **Private** first.
3. Add OAuth scopes.
4. Set redirect URI:
   - `https://YOUR_DOMAIN/api/auth/highlevel/callback`
5. Later switch to **Public** when ready for Marketplace submission.

## Suggested HighLevel embedding

Use a Custom Menu Link or app iframe that points to:

- `https://YOUR_DOMAIN/dashboard`

## Data model summary

- `clients`
- `integration_tokens`
- `posts`
- `interactions`
- `content_suggestions`

## Auto-reply policy

Recommended default mode: `approval`

Only auto-send when:
- no refund request
- no threat / abuse
- no legal language
- no crisis / safety issue
- no pricing dispute

## Files worth editing first

- `backend/app/core/config.py`
- `backend/app/api/routes.py`
- `backend/app/services/ai.py`
- `backend/app/services/facebook.py`
- `backend/app/services/google_business.py`
- `backend/app/services/highlevel.py`
- `.env.example`

## Production notes

For production, you will want to add:
- Alembic migrations
- token rotation hardening
- row-level multi-tenant permissions
- audit log table
- admin auth
- webhook signature verification
- Facebook page selection UI
- Google account/location selection UI
- retry handling and dead-letter queue
- reporting charts
- deeper HighLevel sync

## Marketplace path

### Phase 1
Private app for your agency clients.

### Phase 2
Public marketplace app.

The same codebase supports both paths. The main changes are your HighLevel app configuration, billing, approval screens, and listing assets.

## License

Private internal use until you decide otherwise.
